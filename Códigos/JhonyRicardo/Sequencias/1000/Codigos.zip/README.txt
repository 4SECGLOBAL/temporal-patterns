DataSet -> cria um data set aleatório entre 850 e 1300 itens

Inserção-Padrão -> insere um padrão e exporta esse padrão para um arquivo txt dizendo quais são

Cluster-Padrão -> passa o K means com Ks entre 2 e 100 e roda o apriori em cada K, e exporta o txt com todos os resultados

Grafico-K -> cria um png com todos os Ks que encontraram o padrão

Maiores Resultados -> top 10 padrões mais encontrados no dataset