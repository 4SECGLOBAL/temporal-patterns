# get a dataset from the files and make clusters
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, silhouette_samples
from sklearn.preprocessing import StandardScaler
from math import sqrt, floor
from tqdm import tqdm
import fim
import matplotlib
import scipy.signal as ss

import os
#matplotlib.use('TkAgg')

plt.close("all")
# fazer clusterizacao hierarquica
# C:\...\datasets\Divisao [MConverter.eu].csv

mylist = os.listdir('simulation/synth_with_pattern/fail/')
if len(mylist) % 2 != 0:
    print('failed')

newList = []
for i, listlist in enumerate(mylist):
    if listlist.endswith('.csv'):
        newList.append(mylist[i])


rep_ini = 4
rep_end = 10
rep_stp = 1

size_pat_ini = 2
size_pat_end = 7
size_pat_stp = 1

size_dt_ini = 200
size_dt_end = 1525
size_dt_stp = 25

const_sPat = (size_pat_end - size_pat_ini)/size_pat_stp
const_sDt = (size_dt_end - size_dt_ini)/size_dt_stp
const_rep = (rep_end - rep_ini)/rep_stp

arr_sPat = np.arange(size_pat_ini, size_pat_end, size_pat_stp)
arr_rep = np.arange(rep_ini, rep_end, rep_stp)
list_idx = 0

for list_idx in range(len(newList)):
    metadata = 'timestamp'
    origem = 'origem'
    destino = 'destino'

    selectedEl = newList[list_idx]
    print(f'analysing {selectedEl}')
    data = pd.read_csv(f'simulation/synth_with_pattern/fail/{selectedEl}')
    data_ordenada = data.copy()
    raw_data = data.copy()

    selectedEl_numb = int(selectedEl.replace('.csv', ''))

    num_rep = arr_rep[int(selectedEl_numb // (const_sDt * const_sPat))]
    pat_size = arr_sPat[int((selectedEl_numb // const_sDt) % const_sPat)]


    # keep only the columns that are going to be used
    data = data[[metadata, origem, destino]]
    data[metadata] = pd.to_datetime(data[metadata], dayfirst=False)
    data['timestamp_seconds'] = (data[metadata] - data[metadata].min()).dt.total_seconds()


    # colocar em ordem crescente de timestamp
    data.sort_values(by=metadata, inplace=True)
    data.reset_index(inplace=True, drop=True)


    # contar o numero de vezes que cada item (coluna 0, coluna 1) aparece
    contagem_ocorrencias = data.groupby([origem, destino]).size()
    data['contagem_ocorrencias'] = data.apply(lambda row: contagem_ocorrencias[(row[origem], row[destino])], axis=1)

    # #remove colunas com ocorrencias menores que 2
    # data = data.loc[data['contagem_ocorrencias'] >= 2]
    # data.reset_index(inplace=True, drop=True)

    # Selecionar características relevantes, neste caso, a coluna 'timestamp_seconds' e o numero de vezes que cada item aparece
    # X = data[['timestamp_seconds', 'contagem_ocorrencias']].values
    X = data[['timestamp_seconds']].values

    # Normalizacao dos dados
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # janela de tempo dada pelo usuario dependendo da natureza dos dados
    janela = {'days': 0, 'hours': 0, 'minutes': 20}

    # calcular o numero de clusters ideal atraves da distancia entre os pontos e seus centroides
    # atribui o kmin e kmax de acordo com o numero de baldes que seriam gerados
    kmin = num_rep
    kmax = len(data)//pat_size
    sil = []

    # calcular a matriz de distancias
    distancias = np.zeros((len(X_scaled), len(X_scaled)))
    for i in range(len(X_scaled)):
        for j in range(len(X_scaled)):
            distancias[i][j] = sqrt((X_scaled[i][0] - X_scaled[j][0])**2)


    for k in tqdm(range(kmin, kmax+1), desc='Calculando melhor numero de clusters'):
        kmeans = KMeans(n_clusters = k, random_state=21).fit(X_scaled)
        labels = kmeans.labels_
        sil.append(silhouette_score(distancias, labels, metric='precomputed'))

    plt.plot(range(kmin, kmax + 1), sil)
    plt.plot(range(kmin, kmax + 1), ss.savgol_filter(sil, int(len(sil) * 0.3), 5), '--',
             label='filtrado via savgol')
    plt.xlim(kmin, kmax + 1)

    open(f'simulation/synth_with_pattern/fail_k_tst/{selectedEl.replace("csv", "txt")}', 'w').close()

    for testingK in tqdm(range(kmin+3, kmax+1), desc='Testando cada K'):
        kmeans = KMeans(n_clusters=testingK, random_state=21)
        kmeans.fit(X_scaled)
        clusters = kmeans.labels_
        data['Cluster'] = clusters

        data = data[[origem, destino, 'Cluster']]
        baldes = {}
        for index, row in data.iterrows():
            #z(list(row.values))
            if row['Cluster'] not in baldes:
                baldes[row['Cluster']] = []
            baldes[row['Cluster']].append((row[origem], row[destino]))

        all_buckets = []
        for balde in baldes:
            all_buckets.append(baldes[balde])

        # Apriori
        min_rep = num_rep
        min_conf = 75
        borgelt_rules = fim.apriori(all_buckets,supp=-int(min_rep), conf=min_conf, report='abhC' , zmin=2, target='r')

        # print("Number of rules found: ", len(borgelt_rules))
        # print(borgelt_rules)

        columns_names = ['Consequente', 'Antecedente', 'FR', 'FA', 'FC', 'Conf']
        reordered_columns_names = ['Antecedente', 'Consequente', 'FR', 'FA', 'FC', 'Conf']
        borgelt_rules_df = pd.DataFrame(borgelt_rules, columns=columns_names)
        borgelt_rules_df = borgelt_rules_df[reordered_columns_names]

        borgelt_rules_df = borgelt_rules_df.loc[borgelt_rules_df['FR'] >= int(min_rep)]
        borgelt_rules_df.reset_index(inplace=True, drop=True)

        # Funcao para verificar se um conjunto é subconjunto de outro
        def is_subset(a, b):
            return set(a).issubset(set(b))

        # Lista para armazenar os índices das linhas a serem removidas
        indices_remover = []
        # Iterar sobre cada linha
        for i, row in borgelt_rules_df.iterrows():
            antecedente_atual = row['Antecedente']
            consequente_atual = row['Consequente']

            # Verificar se existe outra linha com antecedente subconjunto e mesmo consequente
            for j, other_row in borgelt_rules_df.iterrows():
                if i != j:  # Evitar comparacao com a mesma linha
                    antecedente_outro = other_row['Antecedente']
                    consequente_outro = other_row['Consequente']

                    if is_subset(antecedente_atual, antecedente_outro) and consequente_atual == consequente_outro:
                        # Além disso, verificar se as outras métricas sao iguais ou menores
                        if other_row['FR'] >= row['FR'] and other_row['FA'] >= row['FA'] and other_row['FC'] >= row['FC'] and other_row['Conf'] >= row['Conf']:
                            indices_remover.append(i)
                        break  # Parar de procurar outras correspondências
        # Remover as linhas com os índices identificados
        rules_found_df = borgelt_rules_df.drop(indices_remover)
        rules_found_df.reset_index(inplace=True, drop=True)

        maxLenborgelt = 0
        for i in range(borgelt_rules_df.shape[0]):
            if maxLenborgelt < len(borgelt_rules_df['Antecedente'][i]):
                maxLenborgelt = len(borgelt_rules_df['Antecedente'][i])

        maxLenborgelt += 1
        if maxLenborgelt == pat_size:
            plt.plot([testingK, testingK], [min(sil), max(sil)], '--', label=f'number of clusters: {testingK}')
            with open(f'simulation/synth_with_pattern/fail_k_tst/{selectedEl.replace("csv", "txt")}', 'a') as f:
                f.write(f"\nChecking the {testingK} clusters case\n")
            with open(f'simulation/synth_with_pattern/fail_k_tst/{selectedEl.replace("csv", "txt")}', 'a') as f:
                f.write(rules_found_df.to_string(header=True, index=True))
            with open(f'simulation/synth_with_pattern/fail_k_tst/{selectedEl.replace("csv", "txt")}', 'a') as f:
                f.write('---------------------------------------------------------------')
            #print(rules_found_df)

    plt.gcf().set_size_inches(18, 10)
    plt.title(f'As clusterizacoes marcadas sao candidatas, numero de rep: {num_rep}, tamanho do padr: {pat_size}, tamanho do dataset: {len(data)}')

    plt.xlabel('Number of clusters')
    plt.ylabel('Silhouette Score')
    plt.savefig(f'simulation/synth_with_pattern/fail_k_tst/{selectedEl.replace("csv", "")}.png', dpi=100)

    plt.legend()
    plt.savefig(f'simulation/synth_with_pattern/fail_k_tst/{selectedEl.replace("csv", "png")}', dpi=100)
    plt.close('all')
