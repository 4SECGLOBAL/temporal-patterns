import numpy as np
import pandas as pd
import random
import datetime
import names
from tqdm import tqdm
import fim
import time
import scipy.signal as ss
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, silhouette_samples
from sklearn.preprocessing import StandardScaler
from math import sqrt, floor
import matplotlib.pyplot as plt


open(f'simulation/synth_with_pattern/resultsApriori.txt', 'w').close()
open(f'simulation/synth_with_pattern/resultsKmeans.txt', 'w').close()
open(f'simulation/synth_with_pattern/resultsFpgrowth.txt', 'w').close()
open(f'simulation/synth_with_pattern/.associationRules.txt', 'w').close()

def gen_synth(data_inicial=[2023, 1, 1], data_final=[2023, 12, 30]):
  # Generate synthetic data
  start = datetime.datetime(data_inicial[0], data_inicial[1], data_inicial[2])
  end = datetime.datetime(data_final[0], data_final[1], data_final[2])

  randList = [random.randint(1, 5000) for i in range(0, 10000)]
  return start, end, randList

def random_dataset(data_inicial, data_final, len_dataset):
  """
  Generate a random dataset

  len_dataset => tamanho do dataset antes da insercao dos dados com padrao
  """

  # gerando um conjunto de dados randomico;
  start, end, randList = gen_synth(data_inicial, data_final)

  # gerando um conjunto de timestamps randomico;
  def random_date():
    return start + datetime.timedelta(seconds=random.randint(0, int((end - start).total_seconds())))

  start_time2 = time.time()
  timestamps = [random_date() for i in range(0, len_dataset)]
  end_time2 = time.time()
  print("Tempo de geracao de datas: {}".format(end_time2 - start_time2))

  # gerando o dataset de acordo com o timestamp e os dados criados anteriormente;
  data = []

  start_time3 = time.time()
  for timestamp in timestamps:
    origem = randList[random.randint(0, 20)]
    destino = randList[random.randint(0, 20)]
    data.append({'timestamp': timestamp, 'origem': origem, 'destino': destino})
  end_time3 = time.time()
  print("Tempo de geracao de dados: {}".format(end_time3 - start_time3))

  return data

def pattern_gen(data_ini, data_fim, len_padrao, num_repeticao, dist_tempo):
  """
  Generate a random dataset

  data_ini => data inicial do dataset
  data_fim => data final do dataset
  len_padrao => quantidade de itens no padrao
  num_repeticao => quantidade de repeticoes do padrao
  dis_tempo => distancia temporal (em segundos máxima) entre os itens do padrao (dentro dos blocos), e distância mínima entre os blocos temporais
  """

  # Passo 1: Criar o range do dataset (data_ini - data_fim)
  start = datetime.datetime(data_ini[0], data_ini[1], data_ini[2])
  end = datetime.datetime(data_fim[0], data_fim[1], data_fim[2])
  _range = int((end - start).total_seconds())

  dist_bloco = len_padrao * dist_tempo

  empty_spc = (_range - dist_bloco * num_repeticao) / (num_repeticao - 1)

  if empty_spc < dist_tempo:
    print("Distancia dos blocos < distancia temporal.")
    return None, None

  data_ini_bloco = np.zeros(num_repeticao)
  data_fim_bloco = np.zeros(num_repeticao)

  for i in range(num_repeticao):
    data_fim_bloco[i] = data_ini_bloco[i] + dist_bloco
    if i != num_repeticao - 1:
      data_ini_bloco[i + 1] = data_fim_bloco[i] + empty_spc

  data = []
  origem = np.zeros(len_padrao)
  destino = np.zeros(len_padrao)

  for i in range(len_padrao):
    origem[i] = random.randint(1, 5000)
    destino[i] = random.randint(1, 5000)

  for i in range(num_repeticao):
    time_ref = data_ini_bloco[i]
    for j in range(len_padrao):
      time_ref = time_ref + random.randint(1, int(dist_tempo * 0.9))

      new_sec = int(time_ref % 60)
      new_min = int((time_ref // 60) % 60)
      new_hour = int((time_ref // 3600) % 24)
      new_day = start.day + int((time_ref // 86400))

      time_ref_rgt = start.replace(day=new_day, hour=new_hour, minute=new_min, second=new_sec)
      data.append({'timestamp': time_ref_rgt, 'origem': origem[j], 'destino': destino[j]})

  rule = np.zeros((len_padrao, 2))
  rule[:, 0] = origem
  rule[:, 1] = destino

  return rule, data


data_inicial = [2023, 1, 1]
data_fim = [2023, 1, 10]
dist_tempo = 25 * 60

og = 0
for num_repeticao in range(4, 10):
  for buckets_it in range(2, 7): #400
    for itens_it in range(200, 1525, 25):
      linhas = itens_it * buckets_it
      # Gerar o arquivo de dados sinteticos de tamanho 'linhas'
      start_time = time.time()
      rule0, pattern0 = pattern_gen(data_inicial, data_fim, buckets_it, num_repeticao, dist_tempo)
      synth = random_dataset(data_inicial, data_fim, itens_it - len(pattern0))

      data = pd.DataFrame(synth + pattern0)
      end_time = time.time()

      print("Tempo de geracao: {}".format(end_time - start_time))
      # Gerar a quantidade de 'buckets' com a quantidade de 'itens'
      start_time = time.time()

      data_ordenada = data.copy()
      raw_data = data.copy()
      metadata = 'timestamp'
      origem = 'origem'
      destino = 'destino'

      # colocar uma COPIA do dataset em ordem cronologica e salvar em csv
      data_ordenada[metadata] = pd.to_datetime(data_ordenada[metadata], dayfirst=True)
      data_ordenada.sort_values(by=metadata, inplace=True)
      data_ordenada.reset_index(inplace=True, drop=True)

      # keep only the columns that are going to be used
      data = data[[metadata, origem, destino]]
      data[metadata] = pd.to_datetime(data[metadata], dayfirst=False)
      data['timestamp_seconds'] = (data[metadata] - data[metadata].min()).dt.total_seconds()

      # colocar em ordem crescente de timestamp
      data.sort_values(by=metadata, inplace=True)
      data.reset_index(inplace=True, drop=True)

      # contar o numero de vezes que cada item (coluna 0, coluna 1) aparece
      contagem_ocorrencias = data.groupby([origem, destino]).size()
      data['contagem_ocorrencias'] = data.apply(lambda row: contagem_ocorrencias[(row[origem], row[destino])], axis=1)

      # #remove colunas com ocorrencias menores que 2
      #data = data.loc[data['contagem_ocorrencias'] >= num_repeticao]
      #data.reset_index(inplace=True, drop=True)

      # Selecionar características relevantes, neste caso, a coluna 'timestamp_seconds' e o numero de vezes que cada item aparece
      # X = data[['timestamp_seconds', 'contagem_ocorrencias']].values
      X = data[['timestamp_seconds']].values

      # Normalizacao dos dados
      scaler = StandardScaler()
      X_scaled = scaler.fit_transform(X)

      # janela de tempo dada pelo usuario dependendo da natureza dos dados
      janela = {'days': 0, 'hours': 0, 'minutes': 20}

      # filtragem para o num de baldes
      # se a distancia entre dois dados eh maior q a janela de dados,
      # cria-se uma "parede" entre os dois dados
      num_baldes = 0
      for i in range(0, len(data[metadata]) - 1):
        if data[metadata][i + 1] - data[metadata][i] > pd.Timedelta(days=float(janela['days']),
                                                                    hours=float(janela['hours']),
                                                                    minutes=float(janela['minutes'])):
          num_baldes += 1

      # calcular o numero de clusters ideal atraves da distancia entre os pontos e seus centroides
      # atribui o kmin e kmax de acordo com o numero de baldes que seriam gerados
      borgelt_rules = []
      plt.close('all')

      kmin = num_repeticao + 1
      kmax = itens_it//buckets_it
      sil = []

      # calcular a matriz de distancias
      distancias = np.zeros((len(X_scaled), len(X_scaled)))
      for i in range(len(X_scaled)):
        for j in range(len(X_scaled)):
          distancias[i][j] = sqrt((X_scaled[i][0] - X_scaled[j][0]) ** 2)

      for k in range(kmin, kmax + 1):
        kmeans = KMeans(n_clusters=k, random_state=21).fit(X_scaled)
        labels = kmeans.labels_
        sil.append(silhouette_score(distancias, labels, metric='precomputed'))


      # pegar o cluster com o maior coeficiente de silhueta e plotar

      cluster_center = sil.index(max(sil[:]))
      print(f'Melhor numero de clusters: {cluster_center}')
      # plt.figure()
      # plt.plot(range(kmin, kmax + 1), sil)
      # plt.xlabel('Number of clusters')
      # plt.ylabel('Silhouette Score')
      # plt.title("num baldes: " + str(num_baldes))
      # plt.show()


      # plt.imshow(distancias)
      # plt.colorbar()
      # plt.show()

      # mostrar os clusters de cada linha de acordo com o melhor cluster

      kmeans = KMeans(n_clusters=cluster_center + kmin)
      kmeans.fit(X_scaled)
      clusters = kmeans.labels_
      data['Cluster'] = clusters

      contagem_cluster = data.groupby(['Cluster']).size()
      data['contagem_cluster'] = data.apply(lambda row: contagem_cluster[row['Cluster']], axis=1)
      data = data.loc[data['contagem_cluster'] >= buckets_it]
      data.reset_index(inplace=True, drop=True)

      # # plot dos clusters em um grafico 2D onde y = 0
      # plt.figure()
      # plt.scatter(data[metadata], np.zeros(len(data[metadata])), c=clusters, cmap='viridis')
      # plt.xlabel('Timestamp')
      # plt.title("Janela: " + str(janela['days']) + "d " + str(janela['hours'])
      #           + "h " + str(janela['minutes']) + "min   " + str(cluster_center) + " balde(s)")
      # plt.show()




      data = data[[origem, destino, 'Cluster']]

      baldes = {}
      for index, row in data.iterrows():
        # print(list(row.values))
        if row['Cluster'] not in baldes:
          baldes[row['Cluster']] = []
        baldes[row['Cluster']].append((row[origem], row[destino]))

      all_buckets = []
      for balde in baldes:
        all_buckets.append(baldes[balde])

      with open('simulation/synth_with_pattern/resultsKmeans.txt', 'a') as f:
        f.write("{},{},{}\n".format(itens_it, buckets_it, time.time() - start_time))
        f.close()


      start_time = time.time()
      print("Apriori")
      min_rep = num_repeticao
      min_conf = 75
      borgelt_rules = fim.apriori(all_buckets, supp=-int(min_rep), conf=min_conf, report='abhC', zmin=2, target='r')


      # print("Number of rules found: ", len(borgelt_rules))
      # print(borgelt_rules)

      columns_names = ['Consequente', 'Antecedente', 'FR', 'FA', 'FC', 'Conf']
      reordered_columns_names = ['Antecedente', 'Consequente', 'FR', 'FA', 'FC', 'Conf']
      borgelt_rules_df = pd.DataFrame(borgelt_rules, columns=columns_names)
      borgelt_rules_df = borgelt_rules_df[reordered_columns_names]

      borgelt_rules_df = borgelt_rules_df.loc[borgelt_rules_df['FR'] >= int(min_rep)]
      borgelt_rules_df.reset_index(inplace=True, drop=True)


      # Funcao para verificar se um conjunto é subconjunto de outro
      def is_subset(a, b):
        return set(a).issubset(set(b))


      # Lista para armazenar os índices das linhas a serem removidas
      indices_remover = []

      # Iterar sobre cada linha
      for i, row in borgelt_rules_df.iterrows():
        antecedente_atual = row['Antecedente']
        consequente_atual = row['Consequente']

        # Verificar se existe outra linha com antecedente subconjunto e mesmo consequente
        for j, other_row in borgelt_rules_df.iterrows():
          if i != j:  # Evitar comparacao com a mesma linha
            antecedente_outro = other_row['Antecedente']
            consequente_outro = other_row['Consequente']

            if is_subset(antecedente_atual, antecedente_outro) and consequente_atual == consequente_outro:
              # Além disso, verificar se as outras métricas sao iguais ou menores
              if other_row['FR'] >= row['FR'] and other_row['FA'] >= row['FA'] and other_row['FC'] >= row['FC'] and \
                      other_row['Conf'] >= row['Conf']:
                indices_remover.append(i)
              break  # Parar de procurar outras correspondências

      # Remover as linhas com os índices identificados
      rules_found_df = borgelt_rules_df.drop(indices_remover)
      rules_found_df.reset_index(inplace=True, drop=True)
      # Resultado final
      print(rules_found_df)
      end_time = time.time()


      #print(f'borgelt: {maxLenborgelt}, rule: {len(rule0)}')
      print("Itens: {} | Buckets: {} | Tempo Apriori: {}".format(itens_it, buckets_it, end_time - start_time))
      with open('simulation/synth_with_pattern/resultsApriori.txt', 'a') as f:
        f.write("{},{},{}\n".format(itens_it, buckets_it, end_time - start_time))
        f.close()

      with open(f'simulation/synth_with_pattern/.associationRules.txt', 'a') as f:
        f.write(f'\n--------------------------------------------------------'
                f'\ncase {og:0>4}\n Expected rule: \n{rule0}\n')

      with open(f'simulation/synth_with_pattern/.associationRules.txt', 'a') as f:
        f.write(f'\n Apriori: \n' + rules_found_df.to_string(header=True, index=True))



      # start_time = time.time()
      # results = fim.eclat(buckets,supp=-int(3), conf=70, report='ab' , zmin=2, target='r')
      # end_time = time.time()
      # print(results)
      #
      # print("Itens: {} | Buckets: {} | Tempo Eclat: {}".format(itens_it, buckets_it, end_time - start_time))
      # with open('resultsEclat.txt', 'a') as f:
      #   f.write("{},{},{}\n".format(itens_it, buckets_it, end_time - start_time))
      #   f.close()

      start_time = time.time()
      print("Fpgrowth")
      min_rep = num_repeticao
      min_conf = 75
      borgelt_rules = fim.apriori(all_buckets, supp=-int(min_rep), conf=min_conf, report='abhC', zmin=2, target='r')

      # print("Number of rules found: ", len(borgelt_rules))
      # print(borgelt_rules)

      columns_names = ['Consequente', 'Antecedente', 'FR', 'FA', 'FC', 'Conf']
      reordered_columns_names = ['Antecedente', 'Consequente', 'FR', 'FA', 'FC', 'Conf']
      borgelt_rules_df = pd.DataFrame(borgelt_rules, columns=columns_names)
      borgelt_rules_df = borgelt_rules_df[reordered_columns_names]

      borgelt_rules_df = borgelt_rules_df.loc[borgelt_rules_df['FR'] >= int(min_rep)]
      borgelt_rules_df.reset_index(inplace=True, drop=True)


      # Funcao para verificar se um conjunto é subconjunto de outro
      def is_subset(a, b):
        return set(a).issubset(set(b))


      # Lista para armazenar os índices das linhas a serem removidas
      indices_remover = []

      # Iterar sobre cada linha
      for i, row in borgelt_rules_df.iterrows():
        antecedente_atual = row['Antecedente']
        consequente_atual = row['Consequente']

        # Verificar se existe outra linha com antecedente subconjunto e mesmo consequente
        for j, other_row in borgelt_rules_df.iterrows():
          if i != j:  # Evitar comparacao com a mesma linha
            antecedente_outro = other_row['Antecedente']
            consequente_outro = other_row['Consequente']

            if is_subset(antecedente_atual, antecedente_outro) and consequente_atual == consequente_outro:
              # Além disso, verificar se as outras métricas sao iguais ou menores
              if other_row['FR'] >= row['FR'] and other_row['FA'] >= row['FA'] and other_row['FC'] >= row[
                'FC'] and \
                      other_row['Conf'] >= row['Conf']:
                indices_remover.append(i)
              break  # Parar de procurar outras correspondências

      # Remover as linhas com os índices identificados
      rules_found_df = borgelt_rules_df.drop(indices_remover)
      rules_found_df.reset_index(inplace=True, drop=True)
      # Resultado final
      print(rules_found_df)
      end_time = time.time()

      print("Itens: {} | Buckets: {} | Tempo Fpgrowth: {}".format(itens_it, buckets_it, end_time - start_time))
      with open('simulation/synth_with_pattern/resultsFpgrowth.txt', 'a') as f:
        f.write("{},{},{}\n".format(itens_it, buckets_it, end_time - start_time))
        f.close()

      print(rule0)
      with open(f'simulation/synth_with_pattern/.associationRules.txt', 'a') as f:
        f.write(f'\n Fpgrowth: \n' + rules_found_df.to_string(header=True, index=True))


      maxLenborgelt = 0
      for i in range(borgelt_rules_df.shape[0]):
        if maxLenborgelt < len(borgelt_rules_df['Antecedente'][i]):
          maxLenborgelt = len(borgelt_rules_df['Antecedente'][i])

      maxLenborgelt += 1


      plt.plot(range(kmin, kmax + 1), sil)
      polyOrder = 5
      if int(len(sil)*0.3) <= 5:
        polyOrder = int(len(sil)*0.1)
      plt.plot(range(kmin, kmax + 1), ss.savgol_filter(sil, int(len(sil)*0.3), polyOrder), '--', label='filtrado via savgol')
      plt.xlim(kmin, kmax + 1)
      plt.plot([sil.index(max(sil[:])) + kmin, sil.index(max(sil[:])) + kmin], [min(sil), max(sil)], '--',
               label=f'melhor clusterizacao (?): {sil.index(max(sil[:])) + kmin}')
      plt.xlabel('Number of clusters')
      plt.ylabel('Silhouette Score')
      if maxLenborgelt == len(rule0):
        with open('simulation/synth_with_pattern/.associationRules.txt', 'a') as f:
          f.write("\n\nSuccess\n")
          f.close()
        plt.title(f'numero de repeticoes: {num_repeticao}, tamanho do padrao: {buckets_it}, tamanho do dataset: {itens_it}, Padrao encontrado')
        plt.legend()
        plt.gcf().set_size_inches(18, 10)
        plt.savefig(f'simulation/synth_with_pattern/success/{og:0>4}.png', dpi=100)

        data_ordenada.to_csv(f'simulation/synth_with_pattern/success/{og:0>4}.csv', index=False)
      elif maxLenborgelt == 1:
        with open('simulation/synth_with_pattern/.associationRules.txt', 'a') as f:
          f.write("\n\nFail\n")
          f.close()
        plt.title(f'numero de repeticoes: {num_repeticao}, tamanho do padrao: {buckets_it}, tamanho do dataset: {itens_it}, Padrao nao encontrado')
        plt.legend()
        plt.gcf().set_size_inches(18, 10)
        plt.savefig(f'simulation/synth_with_pattern/fail/{og:0>4}.png', dpi=100)

        data_ordenada.to_csv(f'simulation/synth_with_pattern/fail/{og:0>4}.csv', index=False)
      else:
        with open('simulation/synth_with_pattern/.associationRules.txt', 'a') as f:
          f.write("\n\nTrunk\n")
          f.close()
        plt.title(
          f'numero de repeticoes: {num_repeticao}, tamanho do padrao: {buckets_it}, tamanho do dataset: {itens_it}, Padrao dividido em partes')
        plt.legend()
        plt.gcf().set_size_inches(18, 10)
        plt.savefig(f'simulation/synth_with_pattern/trunk/{og:0>4}.png', dpi=100)

        data_ordenada.to_csv(f'simulation/synth_with_pattern/trunk/{og:0>4}.csv', index=False)
      og += 1
