import numpy as np
import pandas as pd
import random
import datetime
import names
from numpy.array_api import int64
from tqdm import tqdm
import fim
import time
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, silhouette_samples
from sklearn.preprocessing import StandardScaler
from math import sqrt, floor
from fim import arules
import matplotlib
matplotlib.use('TkAgg')


def gen_synth(data_inicial=[2023, 1, 1], data_final=[2023, 12, 30]):
    # Generate synthetic data
    start = datetime.datetime(data_inicial[0], data_inicial[1], data_inicial[2])
    end = datetime.datetime(data_final[0], data_final[1], data_final[2])

    randList = [random.randint(1, 5000) for i in tqdm(range(0, 10000), desc='Gerando consequentes')]
    return start, end, randList

def random_dataset(data_inicial, data_final, len_dataset):
    """
    Generate a random dataset

    len_dataset => tamanho do dataset antes da insercao dos dados com padrao
    """

    # gerando um conjunto de dados randomico;
    start, end, randList = gen_synth(data_inicial, data_final)


    # gerando um conjunto de timestamps randomico;
    def random_date():
        return start + datetime.timedelta(seconds=random.randint(0, int((end - start).total_seconds())))

    start_time2 = time.time()
    timestamps = [random_date() for i in range(0, len_dataset)]
    end_time2 = time.time()
    print("Tempo de geração de datas: {}".format(end_time2 - start_time2))


    # gerando o dataset de acordo com o timestamp e os dados criados anteriormente;
    data = []

    start_time3 = time.time()
    for timestamp in timestamps:
        origem = randList[random.randint(0, 4999)]
        destino = randList[random.randint(0, 9999)]
        data.append({'timestamp': timestamp, 'origem': origem, 'destino': destino})
    end_time3 = time.time()
    print("Tempo de geração de dados: {}".format(end_time3 - start_time3))

    return data

def pattern_gen(data_ini, data_fim, len_padrao, num_repeticao, dist_tempo):
    """
    Generate a random dataset

    data_ini => data inicial do dataset
    data_fim => data final do dataset
    len_padrao => quantidade de itens no padrão
    num_repeticao => quantidade de repetições do padrão
    dis_tempo => distancia temporal (em segundos máxima) entre os itens do padrão (dentro dos blocos), e distância mínima entre os blocos temporais
    """


    # Passo 1: Criar o range do dataset (data_ini - data_fim)
    start = datetime.datetime(data_ini[0], data_ini[1], data_ini[2])
    end = datetime.datetime(data_fim[0], data_fim[1], data_fim[2])
    _range = int((end - start).total_seconds())

    len_bloco = len_padrao * dist_tempo

    empty_spc = (_range - len_bloco * num_repeticao)/(num_repeticao - 1)

    if empty_spc < dist_tempo:
        print("Distancia dos blocos < distancia temporal.")
        return None, None

    data_ini_bloco = np.zeros(num_repeticao, dtype=int64)
    data_fim_bloco = np.zeros(num_repeticao, dtype=int64)

    for i in range(num_repeticao):
        data_fim_bloco[i] = data_ini_bloco[i] + len_bloco
        if i != num_repeticao - 1:
            data_ini_bloco[i+1] = data_fim_bloco[i] + empty_spc


    data = []
    origem = np.zeros(len_padrao, dtype=int64)
    destino = np.zeros(len_padrao, dtype=int64)

    for i in range(len_padrao):
        origem[i] = random.randint(1, 5000)
        destino[i] = random.randint(1, 5000)


    for i in range(num_repeticao):
        time_ref = data_ini_bloco[i]
        for j in range(len_padrao):
            time_ref = time_ref + random.randint(0, int(dist_tempo*0.9))

            new_sec = int(time_ref % 60)
            new_min = int((time_ref // 60) % 60)
            new_hour = int((time_ref // 3600) % 24)
            new_day = start.day + int((time_ref // 86400))

            time_ref_rgt = start.replace(day=new_day,hour=new_hour, minute=new_min, second=new_sec)
            data.append({'timestamp': time_ref_rgt, 'origem': origem[j], 'destino': destino[j]})

    rule = np.zeros((len_padrao, 2), int64)
    rule[:, 0] = origem
    rule[:, 1] = destino

    return rule, data



data_inicial = [2023, 1, 1]
data_fim = [2023, 1, 5]
dist_tempo = 10 * 60
num_repeticao = 7

time_apriori = np.zeros(20)
time_eclat = np.zeros(20)
time_fpgrowth = np.zeros(20)

time_kmeans = np.zeros(20)
tamanho_fim_padrao = 15
tamanho_dataset_total = 200

for tamanho_do_padraoo in range(2, tamanho_fim_padrao):
    t0 = time.time()
    len_padrao = tamanho_do_padraoo

    rule0, pattern0 = pattern_gen(data_inicial, data_fim, len_padrao, num_repeticao, dist_tempo)
    synth = random_dataset(data_inicial, data_fim, tamanho_dataset_total - len(pattern0))

    data = pd.DataFrame(synth + pattern0)

    plt.close("all")

    data_ordenada = data.copy()
    raw_data = data.copy()
    metadata = 'timestamp'
    origem = 'origem'
    destino = 'destino'

    # colocar uma COPIA do dataset em ordem cronologica e salvar em csv
    data_ordenada[metadata] = pd.to_datetime(data_ordenada[metadata], dayfirst=True)
    data_ordenada.sort_values(by=metadata, inplace=True)
    data_ordenada.reset_index(inplace=True, drop=True)
    data_ordenada.to_csv('Repasses_ordenada.csv', index=False)

    # keep only the columns that are going to be used
    data = data[[metadata, origem, destino]]
    data[metadata] = pd.to_datetime(data[metadata], dayfirst=False)
    data['timestamp_seconds'] = (data[metadata] - data[metadata].min()).dt.total_seconds()

    # colocar em ordem crescente de timestamp
    data.sort_values(by=metadata, inplace=True)
    data.reset_index(inplace=True, drop=True)

    # contar o numero de vezes que cada item (coluna 0, coluna 1) aparece
    contagem_ocorrencias = data.groupby([origem, destino]).size()
    data['contagem_ocorrencias'] = data.apply(lambda row: contagem_ocorrencias[(row[origem], row[destino])], axis=1)

    # #remove colunas com ocorrencias menores que 2
    # data = data.loc[data['contagem_ocorrencias'] >= 2]
    # data.reset_index(inplace=True, drop=True)

    # Selecionar características relevantes, neste caso, a coluna 'timestamp_seconds' e o numero de vezes que cada item aparece
    # X = data[['timestamp_seconds', 'contagem_ocorrencias']].values
    X = data[['timestamp_seconds']].values

    # Normalização dos dados
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # janela de tempo dada pelo usuario dependendo da natureza dos dados
    janela = {'days': 0, 'hours': 0, 'minutes': 20}

    # numero de baldes que seriam gerados caso fosse usado a janela de tempo
    num_baldes = 0
    for i in range(0, len(data[metadata]) - 1):
        if data[metadata][i + 1] - data[metadata][i] > pd.Timedelta(days=float(janela['days']),
                                                                    hours=float(janela['hours']),
                                                                    minutes=float(janela['minutes'])):
            num_baldes += 1

    # calcular o numero de clusters ideal atraves da distancia entre os pontos e seus centroides
    # atribui o kmin e kmax de acordo com o numero de baldes que seriam gerados
    kmin = 2
    kmax = num_baldes + 10
    sil = []

    # calcular a matriz de distancias
    distancias = np.zeros((len(X_scaled), len(X_scaled)))
    for i in range(len(X_scaled)):
        for j in range(len(X_scaled)):
            distancias[i][j] = sqrt((X_scaled[i][0] - X_scaled[j][0]) ** 2)

    for k in tqdm(range(kmin, kmax + 1), desc='Calculando melhor numero de clusters'):
        kmeans = KMeans(n_clusters=k, random_state=21).fit(X_scaled)
        labels = kmeans.labels_
        sil.append(silhouette_score(distancias, labels, metric='precomputed'))

    # pegar o cluster com o maior coeficiente de silhueta e plotar
    cluster_minus_1 = sil.index(max(sil)) - 1
    cluster_center = sil.index(max(sil))
    cluster_plus_1 = sil.index(max(sil)) + 1
    print(f'Melhor numero de clusters: {cluster_minus_1}')
    print(f'Melhor numero de clusters: {cluster_center}')
    print(f'Melhor numero de clusters: {cluster_plus_1}')
    # plt.figure()
    # plt.plot(range(kmin, kmax + 1), sil)
    # plt.xlabel('Number of clusters')
    # plt.ylabel('Silhouette Score')
    # plt.title("num baldes: " + str(num_baldes))
    # plt.show()

    # plt.imshow(distancias)
    # plt.colorbar()
    # plt.show()
    if cluster_center == 0:
        cluster_center = 1
    # mostrar os clusters de cada linha de acordo com o melhor cluster
    kmeans = KMeans(n_clusters=cluster_center)
    kmeans.fit(X_scaled)
    clusters = kmeans.labels_
    data['Cluster'] = clusters

    # # plot dos clusters em um grafico 2D onde y = 0
    # plt.figure()
    # plt.scatter(data[metadata], np.zeros(len(data[metadata])), c=clusters, cmap='viridis')
    # plt.xlabel('Timestamp')
    # plt.title("Janela: " + str(janela['days']) + "d " + str(janela['hours'])
    #           + "h " + str(janela['minutes']) + "min   " + str(cluster_center) + " balde(s)")
    # plt.show()

    data = data[[origem, destino, 'Cluster']]

    baldes = {}
    for index, row in data.iterrows():
        # print(list(row.values))
        if row['Cluster'] not in baldes:
            baldes[row['Cluster']] = []
        baldes[row['Cluster']].append((row[origem], row[destino]))

    all_buckets = []
    for balde in baldes:
        all_buckets.append(baldes[balde])

    time_kmeans[tamanho_do_padraoo] = time.time() - t0

    # apriori
    t0 = time.time()
    print("Apriori")
    min_rep = 6
    min_conf = 75
    borgelt_rules = fim.apriori(all_buckets, supp=-int(min_rep), conf=min_conf, report='abhC', zmin=2, target='r')

    # print("Number of rules found: ", len(borgelt_rules))
    # print(borgelt_rules)

    columns_names = ['Consequente', 'Antecedente', 'FR', 'FA', 'FC', 'Conf']
    reordered_columns_names = ['Antecedente', 'Consequente', 'FR', 'FA', 'FC', 'Conf']
    borgelt_rules_df = pd.DataFrame(borgelt_rules, columns=columns_names)
    borgelt_rules_df = borgelt_rules_df[reordered_columns_names]

    borgelt_rules_df = borgelt_rules_df.loc[borgelt_rules_df['FR'] >= int(min_rep)]
    borgelt_rules_df.reset_index(inplace=True, drop=True)


    # Função para verificar se um conjunto é subconjunto de outro
    def is_subset(a, b):
        return set(a).issubset(set(b))


    # Lista para armazenar os índices das linhas a serem removidas
    indices_remover = []

    # Iterar sobre cada linha
    for i, row in borgelt_rules_df.iterrows():
        antecedente_atual = row['Antecedente']
        consequente_atual = row['Consequente']

        # Verificar se existe outra linha com antecedente subconjunto e mesmo consequente
        for j, other_row in borgelt_rules_df.iterrows():
            if i != j:  # Evitar comparação com a mesma linha
                antecedente_outro = other_row['Antecedente']
                consequente_outro = other_row['Consequente']

                if is_subset(antecedente_atual, antecedente_outro) and consequente_atual == consequente_outro:
                    # Além disso, verificar se as outras métricas são iguais ou menores
                    if other_row['FR'] >= row['FR'] and other_row['FA'] >= row['FA'] and other_row['FC'] >= row['FC'] and \
                            other_row['Conf'] >= row['Conf']:
                        indices_remover.append(i)
                    break  # Parar de procurar outras correspondências

    # Remover as linhas com os índices identificados
    rules_found_df = borgelt_rules_df.drop(indices_remover)
    rules_found_df.reset_index(inplace=True, drop=True)

    time_apriori[tamanho_do_padraoo] = time.time() - t0
    # Resultado final
    print(rules_found_df)


    # fpgrwoth
    t0 = time.time()
    print("Fpgrowth")
    min_rep = 6
    min_conf = 75
    borgelt_rules = fim.apriori(all_buckets, supp=-int(min_rep), conf=min_conf, report='abhC', zmin=2, target='r')

    # print("Number of rules found: ", len(borgelt_rules))
    # print(borgelt_rules)

    columns_names = ['Consequente', 'Antecedente', 'FR', 'FA', 'FC', 'Conf']
    reordered_columns_names = ['Antecedente', 'Consequente', 'FR', 'FA', 'FC', 'Conf']
    borgelt_rules_df = pd.DataFrame(borgelt_rules, columns=columns_names)
    borgelt_rules_df = borgelt_rules_df[reordered_columns_names]

    borgelt_rules_df = borgelt_rules_df.loc[borgelt_rules_df['FR'] >= int(min_rep)]
    borgelt_rules_df.reset_index(inplace=True, drop=True)


    # Função para verificar se um conjunto é subconjunto de outro
    def is_subset(a, b):
        return set(a).issubset(set(b))


    # Lista para armazenar os índices das linhas a serem removidas
    indices_remover = []

    # Iterar sobre cada linha
    for i, row in borgelt_rules_df.iterrows():
        antecedente_atual = row['Antecedente']
        consequente_atual = row['Consequente']

        # Verificar se existe outra linha com antecedente subconjunto e mesmo consequente
        for j, other_row in borgelt_rules_df.iterrows():
            if i != j:  # Evitar comparação com a mesma linha
                antecedente_outro = other_row['Antecedente']
                consequente_outro = other_row['Consequente']

                if is_subset(antecedente_atual, antecedente_outro) and consequente_atual == consequente_outro:
                    # Além disso, verificar se as outras métricas são iguais ou menores
                    if other_row['FR'] >= row['FR'] and other_row['FA'] >= row['FA'] and other_row['FC'] >= row[
                        'FC'] and \
                            other_row['Conf'] >= row['Conf']:
                        indices_remover.append(i)
                    break  # Parar de procurar outras correspondências

    # Remover as linhas com os índices identificados
    rules_found_df = borgelt_rules_df.drop(indices_remover)
    rules_found_df.reset_index(inplace=True, drop=True)

    time_fpgrowth[tamanho_do_padraoo] = time.time() - t0
    # Resultado final
    print(rules_found_df)

    print(rule0)

xax = np.linspace(2, tamanho_do_padraoo-1, tamanho_do_padraoo - 2)

plt.figure()
plt.plot(xax, time_apriori[2:tamanho_do_padraoo], label='apriori')
#plt.plot(time_eclat[:tamanho_do_padraoo+1], label='eclat')
plt.plot(xax, time_fpgrowth[2:tamanho_do_padraoo], label='fpgrowth')
plt.plot(xax, time_kmeans[2:tamanho_do_padraoo], label='kmeans')
plt.xlabel('tamanho do padrao')
plt.ylabel('tempo em segundos')
plt.title(f'Dataset sintetico com tamanho {tamanho_dataset_total}')
plt.legend()
plt.show()

np.savez('tst.npz', apriori=time_apriori[:tamanho_do_padraoo+1],fpgrowth=time_fpgrowth[:tamanho_do_padraoo+1], kmeans=time_kmeans[:tamanho_do_padraoo+1])
# verificar quais regras tem os mesmos elementos, independente da ordem
# antecedentes = []
# consequentes = []
# elementos = []
# for index, row in rules_found_df.iterrows():
#     elementos = row['Antecedente'] + row['Consequente']