import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
import sys
import matplotlib as mpl
mpl.use('Tkagg')

#read data from file
Apriori = np.genfromtxt('simulation/synth_with_pattern/resultsApriori.txt', delimiter=',')
# Eclat = np.genfromtxt('resultsEclat.txt', delimiter=',')
#Arules = np.genfromtxt('resultsArules.txt', delimiter=',')
Fpgrowth = np.genfromtxt('simulation/synth_with_pattern/resultsFpgrowth.txt', delimiter=',')

# %%
# Apriori
#split Apriori into x,y,z
x = Apriori[:,0]
y = Apriori[:,1]
z = Apriori[:,2]

#plot surface using x,y,z
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.plot_trisurf(x, y, z)

#set labels and title
ax.set_title('Apriori time analysis')
ax.set_xlabel('dataset len')
ax.set_ylabel('pattern len')
ax.set_zlabel('time consumption (s)')
plt.show()

# # %%
# # Eclat
# #split Eclat into x,y,z
# x = Eclat[:,0]
# y = Eclat[:,1]
# z = Eclat[:,2]
#
# #plot surface using x,y,z
# fig = plt.figure()
# ax = fig.add_subplot(111, projection='3d')
# ax.plot_trisurf(x, y, z)
#
# #set labels and title
# ax.set_title('Eclat time analysis')
# ax.set_xlabel('itens per bucket')
# ax.set_ylabel('number of buckets')
# ax.set_zlabel('time consumption (s)')
# plt.show()

# # %%
# # Arules
# #split Arules into x,y,z
# x = Arules[:,0]
# y = Arules[:,1]
# z = Arules[:,2]
#
# #plot surface using x,y,z
# fig = plt.figure()
# ax = fig.add_subplot(111, projection='3d')
# ax.plot_trisurf(x, y, z)
#
# #set labels and title
# ax.set_title('Arules time analysis')
# ax.set_xlabel('itens per bucket')
# ax.set_ylabel('number of buckets')
# ax.set_zlabel('time consumption (s)')
# plt.show()

# %%
# Fpgrowth
#split Fpgrowth into x,y,z
x = Fpgrowth[:,0]
y = Fpgrowth[:,1]
z = Fpgrowth[:,2]

#plot surface using x,y,z
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.plot_trisurf(x, y, z)

#set labels and title
ax.set_title('Fpgrowth time analysis')
ax.set_xlabel('dataset len')
ax.set_ylabel('pattern len')
ax.set_zlabel('time consumption (s)')
plt.show()
